import React from 'react';

export default function Hero() {
  return (
    <section >
      <div >
        <div className="container is-max-widescreen">
          <img src="landingpage.jpg" alt="prism pod" />
        </div>
      </div>
    </section>
  )
}
