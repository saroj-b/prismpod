import React from 'react';

export default function CandidateHero() {
  return (
    <section >
      <div >
        <div className="container is-max-widescreen">
          <img src="candidate.jpg" alt="prism pod" />
        </div>
      </div>
    </section>
  )
}
